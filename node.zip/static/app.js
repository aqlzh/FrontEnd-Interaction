// 静态资源访问  问题2


//引入系统模块
const http = require('http') ;
const url = require('url') ; 
const path = require('path') ;
const fs =  require('fs') ;
const mime = require('mime') ;
// 创建网站服务器
const app = http.createServer() ;
// 为网站服务器对象添加请求事件
app.on('request' , (req,res) => {
    // 获取用户的2请求路径
    let pathname =  url.parse(req,url).pathname ;
    pathname = pathname == '/' ?   '/default.html' : pathmame ;
    // 将用户的请求转化为实际的服务器硬盘路径
    let realPath = path.join(__dirname , 'public' + pathname) ;
    console.log(mime.getType(realPath)) ;
     // 读取文件
    fs.readFile(realPath ,(error,result) => {
        if( error != null ){
            res.writeHead(404,{
                'content-type' : 'text/html; charset=utf8'
            })
            res.end('文件读取失败') ;
            return ;
        }
        res.writeHead(200,{
            'content-type' : type 
        }
        res.end(result) 
    })

}) ; 

// 监听窗口
app.listen(3000) ;
console.log('网站服务器启动成功~') ;

// 哪里错了啊？？？