// 静态文件访问代码

//引入系统模块
const http = require('http') ;
const url = require('url') ; 
const path = require('path') ;
const fs =  require('fs') ;
// 创建网站服务器
const app = http.createServer() ;
// 为网站服务器对象添加请求事件
app.on('request' , (req,res) => {
    // 获取用户的2请求路径
    let pathname =  url.parse(req,url).pathname ;
    let realPath = path.join(__dirname , 'public' + pathname) ;
     // 读取文件
    fs.readFile(realPath ,(error,result) => {
        if( error != null ){
            res.writeHead(404,{
                'content-type' : 'text/html; charset=utf8'
            })
            res.end('文件读取失败') ;
            return ;
        }
        res.end(result) 
    })

}) ; 

// 监听窗口
app.listen(3000) ;
console.log('网站服务器启动成功~') ;

// 哪里错了啊？？？   嗷嗷~