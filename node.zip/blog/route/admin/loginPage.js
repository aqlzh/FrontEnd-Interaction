module.exports = (req, res) => {
	res.render('admin/login');
}