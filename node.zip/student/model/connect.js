// 数据库相关操作
const  mongoose = require('mongoose') ;
// 连接数据库
mongoose.connect('mongodb://localhost/playground' ,{ useNewUrlParser :!false}) ;
// 创建网站服务器