//引入系统模块
const http = require('http') ;
const url = require('url') ;    // 应用此代码的原因为，使用其内置parse,返回对象，用其pathname来获取纯粹路径
require('./model/connect.js') 
const app = http.createServer() ;
// 为网站服务器对象添加请求事件
app.on('request' , (req,res) => {
    res.end('ok')  ;
}) ; 

// 监听窗口
app.listen(3000) ;
console.log('网站服务器启动成功~') ;
