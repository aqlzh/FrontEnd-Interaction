const fs = require('fs') ;
fs.writeFile('./demo.txt' ,'即将要写入的文件', err => {
  if( err != null){
      console.log(err) ;
      return ;
  }
  console.log('文件写入成功') ;
 }) ;