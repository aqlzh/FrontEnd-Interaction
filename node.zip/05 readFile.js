const fs =require ('fs')  ;
fs.readFile('./helloworld.js' ,'utf8' , (err,doc) => {
   console.log(err) ;   //  若出错则返回的是一个对象， 否则是一个 null
   console.log(doc) ;    //

}) ;