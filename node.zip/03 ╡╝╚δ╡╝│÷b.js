const a = require('./导入导出a.js')   //其中  。js 可以省略
console.log(a.add(10,20)) ;