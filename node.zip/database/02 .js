const mongoose = require('mongoose') ;

mongoose.connect('mongodb://localhost/playgroud', { useNewUrlParser: true })
        .then(() => console.log('数据库连接成功')) 
        .catch( err => console.log(err,'数据库连接失败')) 

 // 构造函数 -> 创建集合
 // 创建集合规则
const courseSchema = new mongoose.Schema({
    name : String ,
    author : String ,
    isPublished : Boolean 
}) ;
      //使用规则创建集合
 const Course = mongoose.model('Course' , courseSchema)   // course
   
 const course = new Course({
     name : 'node.js 基础' ,
     author : '讲师' ,
     isPublished :! false
 }) ;
 course.save() ;
