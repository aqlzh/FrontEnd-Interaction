//  引用 gulp  模块
const gulp = require('gulp')  ;
const htmlmin = require('gulp-htmlmin') ;
const fileinclude = require('gulp-file-include');
const less = require('gulp-less');
const csso = require('gulp-csso')  ;
const babel = require('gulp-babel') ;   // 关于 js  es6 -> es5
const uglify = require('gulp-uglify') ;  // js 代码压缩
// gulp.task 创建任务
gulp.task('first' ,() => {     //  first 为文件名
    console.log('我的人生中第一个gulp任务执行了') ;
    gulp.src('./src/css/base.css')   // 注意不要加分号
        .pipe(gulp.dest('dist/css')) ;
});
//   html css 任务
// 1.html  代码压缩
// 2. 抽取公共部分
gulp.task('htmlmin', () => {
    gulp.src('./src/*.html')
    // 压缩html 中的代码
    .pipe(htmlmin({ collapseWhitespace : !false}))
    .pipe(gulp.dest('dist'));  // 输出到  dist 中
}) ;
gulp.task('cssmin' ,() => {
    // 选择 css 目录下 的所有 less 文件以及 css文件
    gulp.src(['./src/css/*.less','.src/css/*.css']) 
         //   将less语法  转化为css语法 
        .pipe(less())
        //  将css代码进行压缩
        .pipe(csso())
        // 将处理结果进行输出
        .pipe(gulp.dest('dist/css'))
})

// js 任务
// 1. es6 代码转化
// 2。 代码压缩
gulp.task('jsmin' ,() => {
    gulp.src('./src/js/*.js')
        .pipe(babel({ 
            //  判断当前代码的运行环境 并且转化为符合要求的
         presets:['@babel/env']
        }))
        .pipe(uglify()) 
        .pipe(gulp.dest('dist/js'))
}) ;

// 复制文件 
gulp.task('copy',() => {
    gulp.src('.src/images/*')
        .pipe(gulp.dest('dist/images'));

     gulp.src('.src/font/*')   
        .pipe(gulp.dest('dist/fonts'))
})

//构建 任务
gulp.task('default', ['htmlmin','cssmin','jsmin','copy']) ;