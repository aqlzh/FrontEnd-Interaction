// es6 代码验证
const x = 100;
let y = 200 ;
const fn = () => {
    console.log('123') ;
}
//  验证成功
