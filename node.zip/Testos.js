var os = require('os') ;
console.log(os.platform()) ;