//  目的 public/uploads/avater 
const path = require('path') ;
const finalPath = path.join('public' , 'uploads' ,'avatar') ;
console.log(finalPath) ;