var first = 'hello node js' ;
console.log(first) ;

function fn(){
    console.log('fn 函数被调用') ;
}
fn() ;

for (var i =0 ; i < 5 ;i++) {
    console.log(i) ;
}
if (1){
    console.log('123') ;
}
//  ReferenceError: ture is not defined