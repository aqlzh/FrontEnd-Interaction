// 引入express 模块
const express = require('express') ;
// 路径处理模块
const path = require('path') ;
const app = express() ;
// 静态资源访问服务模块
app.use(express.static(path.join(__dirname , 'public'))) ;
// 监听窗口
app.listen(3000) ;
console.log('服务器启动成功') ;