const http = require('http') ;
// app 对象就是网站服务器duix
const app = http.createServer() ;
// 当客户端游请求时 
const querystring = require('querystring') ;
app.on('request' ,(req,res) => {   // req  请求  res  响应
    
     let postParams = '' ;

     req.on('data' , params => {
         postParams += params ;

     }) ;

     req.on('end' , () => {
         console.log(querystring.parse(postParams)) ;
     })
     res.end('ok') ;
   
})
// 监听窗口
app.listen(3000) ;
console.log('网站服务器启动成功~') ;