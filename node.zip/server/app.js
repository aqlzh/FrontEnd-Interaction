const http = require('http') ;
// app 对象就是网站服务器duix
const app = http.createServer() ;
// 当客户端游请求时

const url = require('url') ; // 用于处理 url 地址

app.on('request' ,(req,res) => {   // req  请求  res  响应
    // 获取请求方式   req..method 
    // console.log(req.method) ;

    // 获取 请求 地址
    // console.log(req.url) ;
    
    // 获取请求报文信息
    // console.log(req.headers['[accept']) ;

    res.writeHead(200 ,{
       // 'content-type': 'text/plain'   纯文本
       'content-type': 'text/html : charset=utf8'
    }) ;
 
    console.log(req.url) ;
      // 1. 要解析的 url 地址
      // 2. 将查询参数解析成对象形式 
    //  let params =  url.parse(req.url ,!false ).query ;  // parse 处理url 地址  字符串 -> 对象
    //  console.log(params.name) ;
    //  console.log(params.age)  ;
   
    // if(req.url == '/index' || req.url == '/'){
    //     res.end('<h2> welcome to homepage</h2>') ;
    // } else if(req.url == '/list'){
    //     res.end('welcome to listpage') ;
    // } else{
    //     res.end('not found') ;
    // }
    // if( req.method == 'POST'){
    //     res.end('post')
    // } else if(req.method == 'GET'){
    //     res.end('get') 
    // }

    //优化
    let {query ,pathname } =  url.parse(req.url ,!false ) ;  
    console.log(query.name) ;
    console.log(query.age)  ;
  
   if(pathname == '/index' || req.url == '/'){
       res.end('<h2> welcome to homepage</h2>') ;
   } else if(pathname == '/list'){
       res.end('welcome to listpage') ;
   } else{
       res.end('not found') ;
   }
   if( req.method == 'POST'){
       res.end('post')
   } else if(req.method == 'GET'){
       res.end('get') 
   }

    // res.end('<h2>hello user </h2>') ;   
})
// 监听窗口
app.listen(3000) ;
console.log('网站服务器启动成功~') ;