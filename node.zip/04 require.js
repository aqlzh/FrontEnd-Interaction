const a = require('./module.exports') ;
console.log(a) ;