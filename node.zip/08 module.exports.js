const greeeting = name => 'hello $(name)' ;
const x = 100 ;
exports.x  = x ;
module.exports.greeeting = greeeting ;

module.exports = {
    name : '高海千歌 ' 
} 