function  getDate (callback){
    callback('123')
} 
getDate(function(n){
    console.log('callback 函数被调用了')
    console.log(n)
}) ;  // 匿名函数