// function getMsg (){
//     setTimeout(function(){
//         return {
//             msg : 'Hello node.js'  
//         }
//     }, 2000)
// }
// const msg = getMsg() ;
// console.log(msg) ;

// 用回调函数解决异步问题

function getMsg (callback){
    setTimeout(function(){
        callback({
            msg : 'Hello node.js' 
        })
    }, 2000)
}

getMsg(function(data){
    console.log(data)
})