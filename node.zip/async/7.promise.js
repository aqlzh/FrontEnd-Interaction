const fs = require('fs') ;

let promise  = new Promise((resolve,reject) => {     // 这 resolve,reject 参数为函数
    fs.readFile('./100.txt' , 'utf8' ,(err,result) => {
        if( err != null ){
            reject(err)  ;
        } else{
            resolve(result);
        }
    })
})
promise.then((result) => {
    console.log(result) ;        //链式编程
})
       .catch((err) => {
           console.log(err) ;
       })